IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[runout_std]') AND type in (N'U'))
    DROP TABLE [dbo].[runout_std]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[runout_std](
	[RUN_CODE] [varchar](20) NULL,
	[SETOFF] [bit] NULL,
	[DEDUCT_B] [float] NULL,
	[DEDUCT_C] [float] NULL,
	[REMARKS] [varchar](100) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO
