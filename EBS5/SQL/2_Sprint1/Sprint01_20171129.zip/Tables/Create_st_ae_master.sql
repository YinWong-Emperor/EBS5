IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[st_ae_master]') AND type in (N'U'))
    DROP TABLE [dbo].[st_ae_master]
GO


/****** Object:  Table [dbo].[st_ae_master]    Script Date: 2017/10/25 10:52:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[st_ae_master](
	[Run_Code] [varchar](20) NULL,
	[Run_Name] [varchar](40) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO
