IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[st_clt_master]') AND type in (N'U'))
    DROP TABLE [dbo].[st_clt_master]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[st_clt_master](
	[CLT_CODE] [varchar](8) NULL,
	[CLT_TYPE] [varchar](1) NULL,
	[CLT_NAME] [varchar](100) NULL,
	[RUN_CODE] [varchar](20) NULL,
	[CR_LIMIT] [float] NULL,
	[CR_BAL] [float] NULL,
	[DR_BAL] [float] NULL,
	[DEPOSIT] [float] NULL,
	[WITHDRAWAL] [float] NULL,
	[AVAIL_BAL] [float] NULL,
	[MKT_VALUE] [float] NULL,
	[MARGIN_VALUE] [float] NULL,
	[MARGIN_RATIO] [float] NULL,
	[NET_TRADE] [float] NULL,
	[T1_UNREALIZED] [float] NULL,
	[T2_UNREALIZED] [float] NULL,
	[INTEREST] [float] NULL,
	[MC_CR_BAL] [float] NULL,
	[MC_DR_BAL] [float] NULL,
	[MC_ACT_RATIO] [float] NULL,
	[MC_DUE] [float] NULL,
	[MC_T2] [float] NULL,
	[MC_OVERDRAFT] [float] NULL,
	[MC_TOTAL] [float] NULL,
	[OS_DAY] [float] NULL,
	[SHORT] [float] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO
