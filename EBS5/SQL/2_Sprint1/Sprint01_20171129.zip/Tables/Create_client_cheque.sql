IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[client_cheque]') AND type in (N'U'))
    DROP TABLE [dbo].[client_cheque]
GO

CREATE TABLE [dbo].[client_cheque](
	[sequence] int NULL,
	[client_code] [varchar](6) NULL,
	[txn_date] [datetime] NULL,
	[amount] [float] NULL,
	[name] [nvarchar](120) NULL,
	[updateby] [varchar](10) NULL,
	[entrydate] [datetime] NULL
) ON [PRIMARY]

GO
