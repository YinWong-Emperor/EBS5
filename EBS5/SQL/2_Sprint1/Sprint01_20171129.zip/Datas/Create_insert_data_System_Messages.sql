
IF NOT EXISTS (SELECT 1 FROM system_messages WHERE sysMsgCode = 126)
   INSERT INTO system_messages (sysMsgCode, sysLang, sysMsg) VALUES (126, 'ENG', 'Client Code already exists!')
ELSE 
   SELECT * FROM system_messages WHERE sysMsgCode = 126

GO
