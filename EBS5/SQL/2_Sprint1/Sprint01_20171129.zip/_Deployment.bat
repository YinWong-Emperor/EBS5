@REM -------Config-------------
@SET DB_IP=172.30.1.80\DB05
@SET DB_Name=ESL_Dev_Test
@SET DB_USER=sa
@SET DB_PWD=sa
@SET LOG=_Deployment%Date:~0,4%%Date:~5,2%%Date:~8,2%%Time:~0,2%%Time:~3,2%%Time:~6,2%.log


@REM -------��������-----------
@cls
@title ESL database scripts
@color 3f
@echo Database��[%DB_Name%] from [%DB_IP%]
@echo Database��[%DB_Name%] from [%DB_IP%] > %LOG%
@echo.
@echo Creating scripts...
@echo.


@REM -------��ʼԤ��������-----
@echo SET NOCOUNT ON > .\_DeployListScripts.sql
@echo GO >> .\_DeployListScripts.sql


@REM -------#1��-----------
@call:LOOP_DEAL_SQL_FILES_FROM_DIR .\Tables

@REM -------#2����---------
@call:LOOP_DEAL_SQL_FILES_FROM_DIR .\Functions

@REM -------#3��ͼ---------
@call:LOOP_DEAL_SQL_FILES_FROM_DIR .\Views

@REM -------#4�洢����-----
@call:LOOP_DEAL_SQL_FILES_FROM_DIR .\StoredProcedures

@REM -------#5����---------
@call:LOOP_DEAL_SQL_FILES_FROM_DIR .\Datas


@REM -------#9��β---------
@echo PRINT ''>> .\_DeployListScripts.sql
@echo PRINT 'All Script Execute Successfully!'>> .\_DeployListScripts.sql


@echo run scripts...
@echo.
@REM -------��ʼִ�нű�-----
@SQLCMD -S %DB_IP% -U %DB_USER% -P %DB_PWD% -d %DB_Name% -i .\_DeployListScripts.sql -b >> %LOG%


@IF %errorlevel% NEQ 0 goto err_handler

@echo Successfully! 
@REM @echo Successfully! Please See log file: %LOG%
@goto exit



@REM ����ָ��Ŀ¼������*.sql�ļ�������
:LOOP_DEAL_SQL_FILES_FROM_DIR
@SET TMP_NAME=%~1 
@SET TMP_NAME=%TMP_NAME:~2,-1%
@echo:>> .\_DeployListScripts.sql
@echo:>> .\_DeployListScripts.sql
@echo PRINT '-------- Executing %TMP_NAME% --------'>> .\_DeployListScripts.sql

@FOR /r %~1 %%i in (*.sql) DO @(
echo PRINT '%~1\%%~nxi' >> .\_DeployListScripts.sql
echo :r "%~1\%%~nxi">> .\_DeployListScripts.sql
echo:>> .\_DeployListScripts.sql
)
@GOTO:EOF  

@REM ������
:err_handler
@color 4f
@REM @echo Failed! Please See log file: %LOG%
@TYPE .\%LOG%
@goto exit

@REM �˳�
:exit
@echo Press any key to continue...
@PAUSE > nul
@exit