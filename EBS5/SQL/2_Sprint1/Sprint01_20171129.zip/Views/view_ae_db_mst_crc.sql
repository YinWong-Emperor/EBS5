
IF EXISTS (select 1 from sys.views where name='view_ae_db_mst_crc' and type='v')
	drop view view_ae_db_mst_crc;
GO


CREATE VIEW [dbo].[view_ae_db_mst_crc] AS
SELECT ISNULL(view_ae_db.run_code, fbal.run_code) AS run_code,
       ISNULL(view_ae_db.run_name, fbal.rname) AS rname,
       ISNULL(ttl_mv,0) AS ttl_mv,
       ISNULL(ttl_dr,0) AS ttl_dr,
       ISNULL(bal,0) AS bal
FROM view_ae_db
INNER JOIN
  (SELECT aeno AS run_code,
          aename AS rname,
          SUM(CASE cuid
                  WHEN '3' THEN (cash_bal * (-0.01) * lastex)
                  ELSE (cash_bal * (-1) * lastex)
              END) AS bal
   FROM dbo.st_ea_fut_bal
   WHERE ROUND(cash_bal,2) < 0
   GROUP BY aeno,
            aename) AS fbal ON view_ae_db.run_code = fbal.run_code


GO
