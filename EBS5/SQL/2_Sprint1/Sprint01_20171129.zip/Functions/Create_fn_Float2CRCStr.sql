
IF OBJECT_ID('dbo.fn_Float2CRCStr') > 0
BEGIN
	DROP FUNCTION dbo.fn_Float2CRCStr
END
GO

CREATE FUNCTION [dbo].[fn_Float2CRCStr](
	@num float
) RETURNS VARCHAR(22)
AS
BEGIN
	IF(@num IS NULL)
	BEGIN
		RETURN '0'
	END

	DECLARE @result VARCHAR(21)

	DECLARE @convertValue DECIMAL(18,2)

	SET @convertValue = CONVERT(DECIMAL,@num)

	IF(ABS(@convertValue) >= 10000.00)
	BEGIN
		
		SET @result = Convert(varchar(20), CAST(CONVERT(DECIMAL(18,2),(@num/1000000)) as Money),1)
		SET @result = ISNULL(@result,'0') + 'M'
	END
	ELSE
	BEGIN
		SET @result = Convert(varchar(20), CAST(CONVERT(DECIMAL(18,2),@num) as Money),1)
	END
	RETURN @result
END
GO