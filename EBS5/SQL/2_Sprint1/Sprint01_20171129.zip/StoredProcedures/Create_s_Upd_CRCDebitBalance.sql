
/****** Object:  StoredProcedure [dbo].[s_Upd_CRCDebitBalance]    Script Date: 2017/10/26 10:41:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*-- =============================================
-- Author : HugoLaw
-- Create date : 2017/10/26 16:19
-- Last update : 2017/10/26 10:47
-- Description : Update Procedure FOR CRCDebitBalance
-- ============================================= */

IF OBJECT_ID('[dbo].[s_Upd_CRCDebitBalance]') > 0
BEGIN
	DROP PROCEDURE [dbo].[s_Upd_CRCDebitBalance]
END
GO

CREATE PROCEDURE [dbo].[s_Upd_CRCDebitBalance]
	@run_code varchar(20) = '',
	@setoff bit,
	@typeB float = 0,
	@typeC float = 0,
	@remark varchar(100) = ''
AS
BEGIN
	
	IF EXISTS(SELECT 1 FROM dbo.runout_std WHERE RUN_CODE = @run_code)
	BEGIN
		UPDATE	dbo.runout_std
		SET		SETOFF = @setoff,
				[DEDUCT_B] = @typeB,
				[DEDUCT_C] = @typeC,
				[REMARKS] = @remark
		WHERE	RUN_CODE = @run_code
	END
	ELSE
	BEGIN
		INSERT INTO dbo.runout_std(RUN_CODE,SETOFF,DEDUCT_B,DEDUCT_C,REMARKS)
		VALUES(@run_code,@setoff,@typeB,@typeC,@remark)
	END

	IF @@ROWCOUNT = 0
	BEGIN
		SELECT -1 AS Status, 'Fail to update the CRCDebitBalance.' AS Msg
	END
	ELSE
	BEGIN
		SELECT 0 AS Status, 'CRCDebitBalance Updated.' AS Msg		
	END
END
GO


--select * from runout_std where run_code = 'S80016'