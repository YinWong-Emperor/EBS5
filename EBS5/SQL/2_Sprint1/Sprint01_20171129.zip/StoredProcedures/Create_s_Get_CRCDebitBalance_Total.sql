
/****** Object:  StoredProcedure [dbo].[s_Get_CRCDebitBalance_Total]    Script Date: 2017/10/26 10:41:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*-- =============================================
-- Author : HugoLaw
-- Create date : 2017/10/26 16:19
-- Last update : 2017/10/26 10:47
-- Description : Search Procedure FOR CRCDebitBalance
-- ============================================= */

IF OBJECT_ID('[dbo].[s_Get_CRCDebitBalance_Total]') > 0
BEGIN
	DROP PROCEDURE [dbo].[s_Get_CRCDebitBalance_Total]
END
GO

CREATE PROCEDURE [dbo].[s_Get_CRCDebitBalance_Total]
	@acCode varchar(20)
AS
BEGIN

	 SELECT 'Total :' + CONVERT(VARCHAR, COUNT(DISTINCT mst.run_code)) AS ttl,
			dbo.[fn_Float2CRCStr](SUM(mst.ttl_mv)) AS mv_str,
			dbo.[fn_Float2CRCStr](SUM(mst.ttl_dr)) AS dr_str,
			(CASE SUM(mst.ttl_mv)
				WHEN 0 THEN CONVERT(VARCHAR,SUM(mst.ttl_mv))
				ELSE CONVERT(VARCHAR,ROUND(((SUM(mst.ttl_dr) / SUM(mst.ttl_mv)) * 100),2))
			END) + '%' AS actr,
			dbo.[fn_Float2CRCStr](SUM(mst.bal)) AS f_dr_bal,
			dbo.[fn_Float2CRCStr](SUM(std.deduct_b)) AS dd_b_str,
			dbo.[fn_Float2CRCStr](SUM(std.deduct_c)) AS dd_c_str
	FROM view_ae_db_mst_crc AS mst
	LEFT OUTER JOIN runout_std AS std ON mst.run_code = std.run_code
	WHERE mst.run_code LIKE '%'+@acCode+'%'
END
GO

