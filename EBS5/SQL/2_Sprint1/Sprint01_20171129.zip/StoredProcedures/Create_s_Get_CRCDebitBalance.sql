
/****** Object:  StoredProcedure [dbo].[s_Get_CRCDebitBalance]    Script Date: 2017/10/26 10:41:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*-- =============================================
-- Author : HugoLaw
-- Create date : 2017/10/26 16:19
-- Last update : 2017/10/26 10:47
-- Description : Search Procedure FOR CRCDebitBalance
-- ============================================= */

IF OBJECT_ID('[dbo].[s_Get_CRCDebitBalance]') > 0
BEGIN
	DROP PROCEDURE [dbo].[s_Get_CRCDebitBalance]
END
GO

CREATE PROCEDURE [dbo].[s_Get_CRCDebitBalance]
	@acCode varchar(20)
AS
BEGIN

	 SELECT mst.run_code,
		   mst.rname AS rname,
		   ttl_mv AS mv,
		   ttl_dr AS dr,
		   dbo.[fn_Float2CRCStr](mst.ttl_mv) AS mv_str,
		   dbo.[fn_Float2CRCStr](mst.ttl_dr) AS dr_str,
		   (CASE mst.ttl_mv
				WHEN 0 THEN CONVERT(VARCHAR,mst.ttl_mv)
				ELSE CONVERT(VARCHAR, ROUND(((mst.ttl_dr / mst.ttl_mv) * 100),2))
			END) + '%' AS actr,
		   mst.bal AS fdr,
		   dbo.[fn_Float2CRCStr](mst.bal) AS f_dr_bal,
		   ISNULL(std.deduct_b, 0) AS dd_b,
		   ISNULL(std.deduct_c, 0) AS dd_c,
		   dbo.[fn_Float2CRCStr](std.deduct_b) AS dd_b_str,
		   dbo.[fn_Float2CRCStr](std.deduct_c) AS dd_c_str,
		   (CASE ISNULL(std.setoff,0)
				WHEN 0 THEN 'No'
				ELSE 'Yes'
			END) AS seto,
		   std.remarks AS remarks,
		   ISNULL(std.deduct_b,0) AS b_type,
		   ISNULL(std.deduct_c,0) AS c_type
	FROM view_ae_db_mst_crc AS mst
	LEFT OUTER JOIN runout_std AS std ON mst.run_code = std.run_code
	WHERE mst.run_code LIKE '%'+@acCode+'%'
END
GO
